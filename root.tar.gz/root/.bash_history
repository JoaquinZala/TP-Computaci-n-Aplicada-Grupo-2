history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
nano /etc/host
apt update 
apt install nano -i
apt install nano -y
ip a
apt install nano -y
sudo apt update && sudo apt install nano -y
echo "nameserver 8.8.8.8" > /etc/resolv.conf
cat /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bullseye main contrib non-free" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bullseye-updates main contrib non-free" >> /etc/apt/source.list
echo "deb http://deb.debian.org/debian-security bullseye-security main contrib non-free" >> /etc/apt/source.list
echo "deb http://deb.debian.org/debian bullseye-updates main contrib non-free" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian-security bullseye-security main contrib non-free" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bullseye-updates main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt install nano -y
echo "127.0.1.1 TPServer" >> /etc/hosts
cat /etc/os-release
apt update && apt upgrade -y
--fix-missing?
--fix-missing
fix-missing
apt get update
apt-get update
/cat/etc/os-release
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
sed -i 's/bullseye-security/bookworm-security/g' /etc/apt/sources.list
cat /etc/apt/sources.list
reboot
cat /etc/os-release
apt update
apt full upgrade -y
apt-full upgrade -y
apt update && apt full-upgrade -y
fix
--fix-missing
--fix
fix-missing
reboot
cat /etc/os-release
sudo apt update
sudo apt upgrade
/etc/apt/source.list
/etc/apt/sources.list
/etc/apt/sources.list
cat /etc/apt/sources.list
cat /etc/os-release
clear
reboot
nano /etc/ssh/sshd_config
ip a
chmod 600 /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
cp /root/clave_publica.pub/root/.ssh/authorized_keys
passwd
cat /etc/network/interfaces
nano /etc/ssh/sshd_config
clear
systemctl restart ssh
system ctl ssh
systemctl ssh
systemctl status ssh
mkdir -p /root/.ssh
cp /root/clave_publica.pub/root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
reboot
nano 
nano /etc/ssh/sshd_config
ls -l root
ls -l #root
ls -l .ssh
cp /root/clave_publica.pub /root/.ssh/authorized_keys
ip a
nano /etc/ssh/sshd_config
reboot
nano /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking
cd..
cd ..
nano /etc/apache2/apache2.config
cd.
cd root
cd /etc/apache2/sites-enabled/
nano /etc/apache2/apache2.config

systemctl restart apache2
systemctl status apache2
clear
cd
mysql -u root -p < db.sql
mysql -u root -p
clear
systemctl restart apache2
ip a
ip route | grep default
nano /etc/network/interfaces
ip a
systemctl restart networking
ip a
apt intall apache2 php libapache2-mod-php php-mysql -y
apt install apache2 php libapache2-mod-php php-mysql -y
systemctl status apache2
ip a
ip a
ip a
ip a
ip a
ip a
systemctl restart networking
ipa
ip a
clear
ip a
ip a
nano /etc/network/interfaces
clear
ip a
systemctl restart sshd_config
systemctl restart ssh
ip route | grep default
nano /etc/network/interfaces
clear
nano /etc/network/interface
clear
nano /etc/network/interface
nano /etc/network/interfaces
clear
ip a
systemctl restart networking
nano /etc/network/interfaces
ip a
nano /etc/network/interfaces
ip a
nano /etc/network/interfaces
nano /etc/network/interfaces
clear
shutdown -h
shutdown -h now
apt install mariadb-server php php-mysq
apt install mariadb-server php php-mysql
mysql -u root -p
cd ...
cd...
cd ..
mkdir www_dir
ls -ld www_dir/
cp /root/index.php /www_dir/
cd /www_dir/
ls
clear
cp /root/logo.png /www_dir/
cp /root/logo.png /var/www_dir/
cp /root/logo.png /var/www/html/
cp /root/logo.png /var/rkdir/html/
cp /root/logo.png /var/wwwrkdir/html/
cp /root/logo.png /www_dir/
ls
nano /etc/apache2/apache2.conf
cd /etc/apache2/
ls
ls -l
cd sites-enabled/
ls
nano
nano 000-default.conf
clear
systemctl restart apache2
asd
asd
a
sd
asd
a
sd
lsblk
clear
df
lsblk
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir
ls
ls -l
mount
mount /dev/sdc1 /www_dir
mkdir -p /backup_dir
mount /dev/sdc2 /backup_dir
ls
ls -l
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
nano /etc/apache2/sites-avaible/000-default.conf
cd cp
cd www_dir
cd /www_dir
ls -l
cp /var/www/html/index.php /www_dir/
cd..
cd ..
mount /dev/sdc2 /backup_dir
mount /dev/sdc1 /www_dir
cd /var
ls -l
cd /etc
ls -l
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
nano /etc/apache2/apache2.conf
nano /etc/apache2/apache2.conf
systemctl restart apache2
systemctl status apache2
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
systemctl restart apache2
sudo tail -f /var/log/apache2/error.log
sudo mv /www_dir/index.php /var/www/html/
cd /etc/
nano /apache2/sites-available/000-default.conf
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
sudo mv /www_dir/index.php /var/www/html/
cd..
cd ..
sudo mv /www_dir/index.php /var/www/html/
sudo cp /www_dir/index.php /var/www/html/
cd root
sudo cp /www_dir/index.php /var/www/html/
ls -l
cd /www_dir
ls -l
sudo cp /www_dir/index.php /var/www/html/
sudo mv /www_dir/index.php /var/www/html/
mv index.php /www_dir/
cd /etc
mv index.php /www_dir/
mv index.php /www_dir
lsblk
ls
ls -a
cd .ssh
ls -l
touch authorized_keys
cd .
cd ..
cat clave_publica.pub > .ssh/authorized_keys 
cd .ssh
ls -l
cd ..
cat clave_publica.pub 
cd .ssh
cat authorized_keys 
cat /proc/partitions > /opt/particion
cat /opt/particion
shutdown -r now
cd /opt
ls -l
cat particion
mkdir -p /opt/scripts
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
cd /backup_diir
cd /backup_dir
cd ..
clear
systemctl status cron.service
cd /backup_dir
cd ..
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
bash .backup_full.sh
bash ./backup_full.sh
./backup_full.sh
./backup_full.sh
nano /opt/scripts/backup_full.sh
cd /opt
./backup_full.sh
nano /opt/scripts/backup_full.sh
cd /
./backup_full.sh
cd ..
cd .
cd root

cd /backup_full.sh
cd /opt
ls -l
ls -l scripts
cd root
cd ..
.scripts/backup_full.sh
.script/backup_full.sh
nano /opt/scripts/backup_full.sh
./scripts backup_full.sh
cd /opt/scripts
ls -l
chmod +x /opt/scripts/backup_full.sh
./backup_full.sh
sudo /opt/scripts/backup_full.sh /var/log
nano /opt/scripts/backup_full.sh
cd ..
cd ..
sudo /opt/scripts/backup_full.sh /var/log
sudo /opt/scripts/backup_full.sh /var/log
nano /opt/scripts/backup_full.sh
sudo /opt/scripts/backup_full.sh /var/log
cd /backup_dir
ls -l
cat var
cat var_log_bkp_20260614.tar.gz 
1;0cexit
clear
