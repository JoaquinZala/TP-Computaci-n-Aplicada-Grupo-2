#!/bin/bash

DESTINO="/backup_dir"

if [[ "$1" == "-help" || "$1" == "-h" ]]; then
    echo "---------------------------------------------------------"
    echo "USO: $0 <directorio_origen>"
    echo "---------------------------------------------------------"
    echo "Este script realiza un backup comprimido de un directorio."
    echo "Los backups se guardan automáticamente en /backup_dir."
    echo ""
    echo "Argumentos:"
    echo "  <directorio_origen>  Ruta absoluta del directorio a respaldar."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log"
    echo "---------------------------------------------------------"	
    exit 0
fi

if [ -z "$1" ]; then
    echo "Error: Debes especificar un directorio. Usa '$0 -help' para ayuda."
    exit 1
fi


ORIGEN=$1
FECHA=$(date +%Y%m%d)

if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio origen '$ORIGEN' no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El destino '$DESTINO' no existe o no está montado."
    exit 1
fi

NOMBRE_BASE=${ORIGEN#/}
NOMBRE_BASE=${NOMBRE_BASE//\//_}

echo "Iniciando el backup de '$ORIGEN'..."

tar -czf "$DESTINO/${NOMBRE_BASE}_bkp_$FECHA.tar.gz" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "¡Backup finalizado con éxito!"
    echo "Archivo guardado: $DESTINO/${NOMBRE_BASE}_bkp_$FECHA.tar.gz"
else
    echo "Error: Falló la creación del archivo de backup."
    exit 1
fi
